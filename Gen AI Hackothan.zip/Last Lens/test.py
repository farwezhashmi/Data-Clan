import streamlit as st
import openai
import wikipediaapi
from PIL import Image
from datetime import datetime
import io

# 🔹 Configure OpenAI API for GPT-3.5 (free model)
def configure_openai():
    try:
        openai.api_key = "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"  # Store the API key securely
        return True
    except Exception as e:
        st.error(f"Error configuring OpenAI API: {str(e)}")
        return False

# 🔹 Get AI-generated landmark description using GPT-3.5 (free)
def get_landmark_description(image_description):
    try:
        # We will use GPT-3.5 to generate the analysis based on the image description
        description_request = openai.Completion.create(
            model="gpt-3.5turbo",  # Using the free GPT-3.5 model
            prompt=f"Analyze the following landmark description and provide:\n"
                   "1. Name of the landmark\n"
                   "2. Historical significance\n"
                   "3. Architectural features\n"
                   "4. Best time to visit\n"
                   "5. Interesting facts\n\n"
                   "Description:\n{image_description}\n",
            max_tokens=500
        )

        return description_request.choices[0].text.strip() if description_request else "No response from AI."

    except Exception as e:
        return f"🔴 Error analyzing description: {str(e)}"

# 🔹 Fetch Wikipedia summary
def get_wikipedia_info(landmark_name):
    try:
        wiki_wiki = wikipediaapi.Wikipedia('en')
        page = wiki_wiki.page(landmark_name)

        if page.exists():
            return {
                'summary': page.summary[:1000],  # Limit to 1000 chars
                'url': page.fullurl
            }
        return None  # No Wikipedia page found
    except Exception as e:
        return f"🔴 Error fetching Wikipedia info: {str(e)}"

# 🔹 Process and display image analysis (based on provided description)
def process_image(image_file):
    # Load and show image
    image = Image.open(image_file)
    st.image(image, caption="📍 Landmark Image", use_container_width=True)

    with st.spinner("🔍 Analyzing landmark..."):
        # You would typically use an external image recognition API here for the description
        # Here we will assume the image description is pre-generated and provided
        image_description = "This is a placeholder description for the landmark image."

        # Get landmark description using GPT-3.5 (text generation)
        description = get_landmark_description(image_description)

        # Extract landmark name (assuming it's the first line)
        landmark_name = description.split('\n')[0].replace("Name of the landmark:", "").strip()

        # Get Wikipedia info
        wiki_info = get_wikipedia_info(landmark_name)

        # UI Layout
        col1, col2 = st.columns([2, 1])

        with col1:
            st.subheader("🤖 AI Analysis")
            st.write(description)

            if isinstance(wiki_info, dict):
                st.subheader("📚 More Info")
                st.write(wiki_info['summary'])
                st.markdown(f"[Read more on Wikipedia]({wiki_info['url']})")

        with col2:
            st.subheader("📍 Quick Tips")
            st.info("""
            - 📸 Best photo spots
            - ⏰ Opening hours
            - 🎫 Ticket information
            - 🚶‍♂ Guided tours
            """)

            # Downloadable Report
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report = f"""
            Landmark Analysis Report
            Generated on: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            
            {description}
            
            Additional Information:
            {wiki_info['summary'] if isinstance(wiki_info, dict) else 'No Wikipedia info available'}
            """
            
            st.download_button(
                label="📥 Download Report",
                data=report,
                file_name=f"landmark_report_{timestamp}.txt",
                mime="text/plain"
            )

# 🔹 Main Streamlit App
def main():
    st.set_page_config(
        page_title="AI Landmark Explorer",
        page_icon="🏛",
        layout="wide"
    )

    st.title("🏛 AI Landmark Explorer")
    st.write("Upload or capture an image to get details about famous landmarks!")

    # Configure OpenAI API
    if not configure_openai():
        st.error("🔴 OpenAI API initialization failed. Check API key.")
        return

    # Tabs for input
    tab1, tab2 = st.tabs(["📸 Camera Capture", "🖼 Upload Image"])

    with tab1:
        st.header("Take a Photo")
        camera_photo = st.camera_input("Capture landmark")
        if camera_photo:
            process_image(camera_photo)

    with tab2:
        st.header("Upload an Image")
        uploaded_file = st.file_uploader("Choose an image...", type=['jpg', 'jpeg', 'png'])
        if uploaded_file:
            process_image(uploaded_file)

if __name__ == "__main__":
    main()
