import streamlit as st
from transformers import pipeline
import wikipediaapi

def configure_huggingface():
    """Initialize and configure Hugging Face model for text generation."""
    try:
        model_name = "mistralai/Mistral-7B-Instruct"  # You can replace with another model
        generator = pipeline("text-generation", model=model_name)
        return generator
    except Exception as e:
        st.error(f"⚠️ Error configuring Hugging Face model: {str(e)}")
        return None

def get_wikipedia_info(landmark_name):
    """Fetch summary and URL of a landmark from Wikipedia."""
    try:
        wiki_wiki = wikipediaapi.Wikipedia('en')
        page = wiki_wiki.page(landmark_name)

        if page.exists():
            return {
                'summary': page.summary[:1000],  # Limit summary to 1000 characters
                'url': page.fullurl
            }
        else:
            return None  # Landmark not found on Wikipedia

    except Exception as e:
        return f"⚠️ Error fetching Wikipedia information: {str(e)}"

