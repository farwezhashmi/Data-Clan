import streamlit as st
from transformers import pipeline
import wikipediaapi
from PIL import Image
import io
from datetime import datetime
import os

# 🔹 Configure Hugging Face Model
@st.cache_resource
def configure_huggingface(api_key):
    """Initialize and configure Hugging Face model for image-to-text generation."""
    try:
        os.environ["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"] = api_key  # Set API key as an environment variable
        model_name = "Salesforce/blip-image-captioning-large"  # BLIP model for image captioning
        image_captioner = pipeline("image-to-text", model=model_name)
        return image_captioner
    except Exception as e:
        st.error(f"⚠️ Error configuring Hugging Face model: {str(e)}")
        return None

# 🔹 Get AI-generated landmark description
def get_landmark_description(model, image):
    """Generate a landmark description from an image using a Hugging Face model."""
    try:
        img_bytes = io.BytesIO()
        image.save(img_bytes, format="PNG")
        img_bytes = img_bytes.getvalue()

        # Generate a caption
        response = model(image)
        if response:
            return response[0]['generated_text']
        else:
            return "No description generated."
    except Exception as e:
        return f"🔴 Error analyzing image: {str(e)}"

# 🔹 Fetch Wikipedia summary
def get_wikipedia_info(landmark_name):
    """Fetch Wikipedia summary and URL of a landmark."""
    try:
        wiki_wiki = wikipediaapi.Wikipedia('en')
        page = wiki_wiki.page(landmark_name)

        if page.exists():
            return {
                'summary': page.summary[:1000],  # Limit to 1000 characters
                'url': page.fullurl
            }
        return None  # No Wikipedia page found
    except Exception as e:
        return f"🔴 Error fetching Wikipedia info: {str(e)}"

# 🔹 Process and display image analysis
def process_image(image_file, model):
    """Process the uploaded image and generate landmark details."""
    image = Image.open(image_file)
    st.image(image, caption="📍 Landmark Image", use_container_width=True)

    with st.spinner("🔍 Analyzing landmark..."):
        description = get_landmark_description(model, image)

        # Extract landmark name (assuming the name appears in the first words)
        landmark_name = description.split('.')[0]  # Taking the first sentence

        # Get Wikipedia info
        wiki_info = get_wikipedia_info(landmark_name)

        # UI Layout
        col1, col2 = st.columns([2, 1])

        with col1:
            st.subheader("🤖 AI Analysis")
            st.write(f"**Landmark:** {landmark_name}")
            st.write(description)

            if isinstance(wiki_info, dict):
                st.subheader("📚 More Info")
                st.write(wiki_info['summary'])
                st.markdown(f"[Read more on Wikipedia]({wiki_info['url']})")

        with col2:
            st.subheader("📍 Quick Tips")
            st.info("""
            - 📸 Best photo spots
            - ⏰ Opening hours
            - 🎫 Ticket information
            - 🚶‍♂ Guided tours
            """)

            # Downloadable Report
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report = f"""
            Landmark Analysis Report
            Generated on: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

            **Landmark:** {landmark_name}

            {description}

            **Additional Information:**
            {wiki_info['summary'] if isinstance(wiki_info, dict) else 'No Wikipedia info available'}
            """

            st.download_button(
                label="📥 Download Report",
                data=report,
                file_name=f"landmark_report_{timestamp}.txt",
                mime="text/plain"
            )

# 🔹 Main Streamlit App
def main():
    st.set_page_config(
        page_title="AI Landmark Explorer",
        page_icon="🏛",
        layout="wide"
    )

    st.title("🏛 AI Landmark Explorer")
    st.write("Upload or capture an image to get details about famous landmarks!")

    # Sidebar for API Key Input
    st.sidebar.header("🔑 API Key Settings")
    user_api_key = st.sidebar.text_input("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", type="password")
    
    # Load API Key from Streamlit Secrets if available
    stored_api_key = st.secrets.get("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", "")
    api_key = user_api_key if user_api_key else stored_api_key  # Use user input if provided

    if not api_key:
        st.sidebar.error("❌ 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`.")
        return

    # Load Hugging Face model
    model = configure_huggingface(api_key)
    if not model:
        st.error("🔴 AI model initialization failed. Check API key.")
        return

    # Tabs for input
    tab1, tab2 = st.tabs(["📸 Camera Capture", "🖼 Upload Image"])

    with tab1:
        st.header("Take a Photo")
        camera_photo = st.camera_input("Capture landmark")
        if camera_photo:
            process_image(camera_photo, model)

    with tab2:
        st.header("Upload an Image")
        uploaded_file = st.file_uploader("Choose an image...", type=['jpg', 'jpeg', 'png'])
        if uploaded_file:
            process_image(uploaded_file, model)

if __name__ == "__main__":
    main()
