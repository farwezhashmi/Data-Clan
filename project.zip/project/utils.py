import openai
import wikipediaapi
import streamlit as st

def configure_openai():
    """Initialize and configure OpenAI API."""
    try:
        # Fetch API key securely from secrets.toml
        openai.api_key = st.secrets["openai"]["api_key"]  # Ensure your OpenAI API key is stored in secrets.toml
        return True
    except KeyError:
        st.error("❌ API Key not found! Please check `secrets.toml` file.")
        return False
    except Exception as e:
        st.error(f"⚠️ Error configuring OpenAI API: {str(e)}")
        return False

def get_openai_landmark_description(image_description):
    """Generate description about a landmark using GPT-3.5 Turbo."""
    try:
        # Example prompt for GPT-3.5 Turbo to generate detailed description
        prompt = f"Analyze the following description and provide:\n1. Name of the landmark\n2. Historical significance\n3. Architectural features\n4. Best time to visit\n5. Interesting facts\n\nDescription: {image_description}"
        
        # Make the OpenAI API call to generate the description
        response = openai.Completion.create(
            model="gpt-3.5-turbo",
            prompt=prompt,
            max_tokens=500,  # Adjust token count as needed
            temperature=0.7
        )
        
        return response.choices[0].text.strip() if response else "No response from GPT-3.5."
    
    except Exception as e:
        return f"⚠️ Error analyzing description: {str(e)}"

def get_wikipedia_info(landmark_name):
    """Fetch summary and URL of a landmark from Wikipedia."""
    try:
        wiki_wiki = wikipediaapi.Wikipedia('en')
        page = wiki_wiki.page(landmark_name)

        if page.exists():
            return {
                'summary': page.summary[:1000],  # Limit summary to 1000 characters
                'url': page.fullurl
            }
        return None  # Landmark not found on Wikipedia

    except Exception as e:
        return f"⚠️ Error fetching Wikipedia information: {str(e)}"

