import wikipediaapi

def get_wikipedia_info(landmark_name):
    try:
        wiki_wiki = wikipediaapi.Wikipedia('en')
        page = wiki_wiki.page(landmark_name)

        if page.exists():
            return {
                'summary': page.summary[:1000],  # Limit summary to 1000 characters
                'url': page.fullurl
            }
        else:
            return None  # Landmark not found on Wikipedia

    except Exception as e:
        return f"Error fetching Wikipedia information: {str(e)}"
