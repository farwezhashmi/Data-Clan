import streamlit as st
import google.generativeai as genai

@st.cache_resource
def configure_gemini():
    try:
        genai.configure(api_key=st.secrets["AIzaSyBz8gamex4PivYRLIPk1AYbVnlIvRflS3I"])
        return genai.GenerativeModel('gemini-pro-vision')
    except Exception as e:
        st.error(f"Error configuring Gemini API: {str(e)}")
        return None
